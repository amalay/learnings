﻿param
(
    [parameter(Mandatory=$true)]
    [string]$certificateName
)
$certLocation = "Cert:\CurrentUser\My"

$wildCardForCertificate= "*"+$certificateName+"*"

$installedCertificateDetails = Get-ChildItem -Path cert:\CurrentUser\My -DnsName $wildCardForCertificate

if($installedCertificateDetails -ne $null)
{
   Write-Host "Deleting Certificate Stored"
   
   $certPath = $certLocation+"\"+$installedCertificateDetails.Thumbprint
   Remove-Item -Path $certPath -DeleteKey 
}

$pfxPath = [Environment]::GetFolderPath("Desktop") +"\"+ $certificateName+ ".pfx"

if(Test-Path $pfxPath)
{
    Write-Host "Deleting the pfx file"
    Remove-Item -Path $pfxPath
}



