﻿param
(
    [parameter(Mandatory=$true)]
    [string]$keyVaultName, 
    [parameter(Mandatory=$true)]
    [string]$certificateName, 
    [parameter(Mandatory = $true)]
    [string]$certificateTemporaryStore 
)

if(!$certificateTemporaryStore.EndsWith("/"))
{
    $certificateTemporaryStore = $certificateTemporaryStore + "/"
}

$pfxPath = $certificateTemporaryStore + $certificateName+ ".pfx"

$certificatePassword = $null

$kvSecret = Get-AzureKeyVaultSecret -VaultName $keyVaultName -Name $certificateName
$kvSecretBytes = [System.Convert]::FromBase64String($kvSecret.SecretValueText)
$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$certCollection.Import($kvSecretBytes,$null,[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)

$protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx, $certificatePassword)
[System.IO.File]::WriteAllBytes($pfxPath, $protectedCertificateBytes)

$certLocation = "Cert:\CurrentUser\My"
    
$installedCertificateDetails = Import-PfxCertificate -FilePath $pfxPath -CertStoreLocation $certLocation -Exportable -Password $certpwd

$installedCertificateDetails.Thumbprint